package com.cg.hotelmanag.dao;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hotelmanag.entities.HotelBooking;


public interface HotelBookingDao extends JpaRepository<HotelBooking, Integer> {

	
	//public HotelBooking insertHotel(String hotelId );
	//public HotelBooking retrieveByHotelById(String hotelId );
	public ArrayList<HotelBooking> findByCity(String city );
	//public HotelBooking deleteHotel(String hotelId );
	//public HotelBooking modifyHotel(String hotelId,String description );
	
	
}
