package com.cg.hotelmanag.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hotelmanag.dao.HotelBookingDao;
import com.cg.hotelmanag.entities.HotelBooking;


@RestController
public class HotelBookingController {
	@Autowired
HotelBookingDao hbd;

	@PostMapping(value="/insert/hotel",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String insert(@RequestBody HotelBooking hb )
	{
		hbd.save(hb);
		return "****Successfully Inserted****\n Your Hotel ID is "+hb.getHotelId();
	}
	
	@GetMapping("/retrieveById/{hotelId}")
	public HotelBooking retrieveHotel(@PathVariable("hotelId") int hotelId)
	{
		HotelBooking h1=hbd.findById(hotelId).get();
		return h1;
	}
	
	//User Defined Function
	@GetMapping("/retrieveByCity/{city}")
	public ArrayList<HotelBooking> retrieveByName(@PathVariable("city") String city)
	{
		ArrayList<HotelBooking> h2=hbd.findByCity(city);
		return h2;	
	}
		
	@GetMapping(value="/retrieveAll")
	public List<HotelBooking> getAll()
	{
	return  hbd.findAll();
		    
    }
		
		
	@DeleteMapping("/delete/{hotelId}")
	public String deleteEmployee(@PathVariable("hotelId") int hotelId)
	{
		hbd.deleteById(hotelId);
		return "Deleted";
	}
		
	@PutMapping("/update/{hotelId}/{description}")
	public String updateDescription(@PathVariable("hotelId") int hotelId,@PathVariable("description") String description) 
    {
		HotelBooking h3=hbd.findById(hotelId).get();
		h3.setDescription(description);
		hbd.save(h3);
		return "Updated";
    }
	
	

	
}
