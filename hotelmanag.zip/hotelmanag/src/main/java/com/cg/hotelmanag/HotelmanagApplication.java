package com.cg.hotelmanag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelmanagApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelmanagApplication.class, args);
	}
}
