package com.cg.Project.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Project.Bean.JobApplied;





public interface JobAppliedDao extends JpaRepository<JobApplied, String> {

}
